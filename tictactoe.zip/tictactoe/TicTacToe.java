package tictactoe;

import java.util.Scanner;

/**
 * @author Falguni Das Shuvo
 */
public class TicTacToe {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TicTacToe_Problem game = new TicTacToe_Problem();
        MiniMax minimax = new MiniMax(game);
    
        
        char [] state = new char[9];
        for(int i=0; i < 9; i++)
            state[i] = '0';
        while(true){
             int playerAction = scanner.nextInt();
             state[playerAction] = 'x';
             int computerAction = MiniMax.minimaxDecision(state);
             state[computerAction] = '*';
             System.out.println(computerAction);
             int i=0;
             for(char ch : state){
                 i++;
                 System.out.print(ch);
                 if(i%3 == 0)
                     System.out.println();
             }
			 
			 char cpyState[] = new char[9];
			 
			 for(int z=0; z < 9; z++)
				 if(state[z] == '0')
					 cpyState[z] = '\0';
				 else
					 cpyState[z] = state[z];
				 
			 
			System.out.println(cpyState[0] + " | " + cpyState[1] + " | " + cpyState[2]);
			System.out.println("---------");
			System.out.println(cpyState[3] + " | " + cpyState[4] + " | " + cpyState[5]);
			System.out.println("---------");
			System.out.println(cpyState[6] + " | " + cpyState[7] + " | " + cpyState[8]);
			//System.out.println("_________");
        }
        
    }
   
}
