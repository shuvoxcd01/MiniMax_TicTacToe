
package tictactoe;

import java.util.ArrayList;

/**
 * @author Falguni Das Shuvo
 */
 
public class TicTacToe_Problem {
    char [] initialState;
    char max_symbol;
    char min_symbol;
   

   public TicTacToe_Problem(){
        initialState = new char[9];
        for(int i=0; i< 9; i++)
            initialState[i] = '0';
        max_symbol = '*';
        min_symbol = 'x';
    }
	
  //  boolean player(char [] state); // true for max, false for min
  
  
    Integer [] actions(char [] state){
        ArrayList <Integer> actionList = new ArrayList <> ();
        for(int i=0; i < 9; i++)
            if(state[i] == '0')
                actionList.add(i);
        return actionList.toArray(new Integer[actionList.size()]);
    }
	
    char [] result(char [] state, int action, boolean player){
        char copyState[] = new char[9];
        System.arraycopy(state, 0, copyState, 0, 9);
        
        if(player){
            copyState[action] = max_symbol;
        }
        else{
            copyState[action] = min_symbol;
        }
    
        return copyState;
    }
	
	boolean isRowDone(char [] state){
		
			if(state[0] == max_symbol && state[1] == max_symbol && state[2] == max_symbol) return true;
			else if(state[3] == max_symbol && state[4] == max_symbol && state[5] == max_symbol) return true;
			else if(state[6] == max_symbol && state[7] == max_symbol && state[8] == max_symbol) return true;
	
	
			else if(state[0] == min_symbol && state[1] == min_symbol && state[2] == min_symbol) return true;
			else if(state[3] == min_symbol && state[4] == min_symbol && state[5] == min_symbol) return true;
			else if(state[6] == min_symbol && state[7] == min_symbol && state[8] == min_symbol) return true;
			else return false;
	
	}
	
	boolean isColumnDone(char [] state){
	
			if(state[0] == max_symbol && state[3] == max_symbol && state[6] == max_symbol) return true;
			else if(state[1] == max_symbol && state[4] == max_symbol && state[7] == max_symbol) return true;
			else if(state[2] == max_symbol && state[5] == max_symbol && state[8] == max_symbol) return true;
	
	
			else if(state[0] == min_symbol && state[3] == min_symbol && state[6] == min_symbol) return true;
			else if(state[1] == min_symbol && state[4] == min_symbol && state[7] == min_symbol) return true;
			else if(state[2] == min_symbol && state[5] == min_symbol && state[8] == min_symbol) return true;
			else return false;
	
	}
	
	boolean isDiagonalDone(char [] state){
		
			if(state[0] == max_symbol && state[4] == max_symbol && state[8] == max_symbol) return true;
			else if(state[2] == max_symbol && state[4] == max_symbol && state[6] == max_symbol) return true;
			
		
	
			else if(state[0] == min_symbol && state[4] == min_symbol && state[8] == min_symbol) return true;
			else if(state[2] == min_symbol && state[4] == min_symbol && state[6] == min_symbol) return true;
			else return false;
	}
	
	
	
    boolean terminalTest(char [] state){
        if(isRowDone(state) || isColumnDone(state) || isDiagonalDone(state)){
            return true;
        }
		else {
            for(int i=0; i<9; i++)
                if(state[i] == '0')
                    return false;
            return true;
        }
    }
    
    int utility(char [] state){
    
	 if(     state[0]==max_symbol && state[1]==max_symbol && state[2]==max_symbol 
		|| state[3]==max_symbol && state[4]==max_symbol && state[5]==max_symbol
		|| state[6]==max_symbol && state[7]==max_symbol && state[8]==max_symbol 
		|| state[0]==max_symbol && state[3]==max_symbol && state[6]==max_symbol
		|| state[1]==max_symbol && state[4]==max_symbol && state[7]==max_symbol
		|| state[2]==max_symbol && state[5]==max_symbol && state[8]==max_symbol
		|| state[0]==max_symbol && state[4]==max_symbol && state[8]==max_symbol
		|| state[2]==max_symbol && state[4]==max_symbol && state[6]==max_symbol
		){

			return 1;
		}         
	else if(   state[0]==min_symbol && state[1]==min_symbol && state[2]==min_symbol 
			|| state[3]==min_symbol && state[4]==min_symbol && state[5]==min_symbol
			|| state[6]==min_symbol && state[7]==min_symbol && state[8]==min_symbol 
			|| state[0]==min_symbol && state[3]==min_symbol && state[6]==min_symbol
			|| state[1]==min_symbol && state[4]==min_symbol && state[7]==min_symbol
			|| state[2]==min_symbol && state[5]==min_symbol && state[8]==min_symbol
			|| state[0]==min_symbol && state[4]==min_symbol && state[8]==min_symbol
			|| state[2]==min_symbol && state[4]==min_symbol && state[6]==min_symbol
			){
			return -1;
		}
   
		else return 0;
    }
}
