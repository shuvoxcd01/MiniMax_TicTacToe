package tictactoe;

/**
 * @author Falguni Das Shuvo
 */
 
public class MiniMax {
    static TicTacToe_Problem game;
	
    public MiniMax(TicTacToe_Problem problem){
        game = problem;
    }
	
    public static int minimaxDecision(char [] state){
        int result, action;
        action = 100;
        result = -100;
        int temp;
        for(int a : game.actions(state)){
            temp = minValue(game.result(state, a, true)); //false because next turn is Min's. << This statement is bullshit.!! Computer always plays from max's point of view.
            if(temp > result){
                result = temp;
                action = a;
            }
        }
        return action;
    }
    
    static int maxValue(char [] state){
        if(game.terminalTest(state)){
            return game.utility(state);
        }
        
        int v = -100;
        int temp;
        for(int a : game.actions(state)){
            temp = minValue(game.result(state, a, true));
            if(temp > v)
                v = temp;
        }
        return v;
    }
    
    static int minValue(char [] state){
        if(game.terminalTest(state)){
            return game.utility(state);
        }
        
        int v = 100;
        int temp;
        for(int a : game.actions(state)){
            temp = maxValue(game.result(state, a, false));
            if(temp < v)
                v = temp;
        }
        return v;
    }
}
